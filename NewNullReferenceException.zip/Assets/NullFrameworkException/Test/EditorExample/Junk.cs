using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class Junk : MonoBehaviour
{
    [Range(0, 69)]public int variableOne;
    public float variableTwo;
    public Vector3 variableThree;


}
