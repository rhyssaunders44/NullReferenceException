using System.Collections;

namespace NullFrameworkException
{
    public interface ISort
    {

    }
}
