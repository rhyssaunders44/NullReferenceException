using UnityEngine;

namespace NullFrameworkException
{
    public class ReadOnlyAttribute : PropertyAttribute
    {
        
    }
}